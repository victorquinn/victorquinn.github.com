var timeline1_data = {  // save as a global variable
'dateTimeFormat': 'iso8601',
'wikiURL': "http://simile.mit.edu/shelf/",
'wikiSection': "Simile Cubism Timeline",

'events' : [
		{'start': '1922',
		'title': 'Blah Test Blah',
		'description': 'by Lyonel Feininger, American/German Painter, 1871-1956',
		'image': 'http://images.allposters.com/images/AWI/NR096_b.jpg',
		'link': 'http://www.allposters.com/-sp/Barfusserkirche-1924-Posters_i1116895_.htm',
		'organization': 'A'
		},
		{'start': '1924',
		'title': 'Test Sample',
		'description': 'by Lyonel Feininger, American/German Painter, 1871-1956',
		'image': 'http://images.allposters.com/images/AWI/NR096_b.jpg',
		'link': 'http://www.allposters.com/-sp/Barfusserkirche-1924-Posters_i1116895_.htm',
 		'organization': 'A'
		},
        {'start': '1924',
        'title': 'Barfusserkirche',
        'description': 'by Lyonel Feininger, American/German Painter, 1871-1956',
        'image': 'http://images.allposters.com/images/AWI/NR096_b.jpg',
        'link': 'http://www.allposters.com/-sp/Barfusserkirche-1924-Posters_i1116895_.htm',
   		'organization': 'A'
        }
]
};

var timeline2_data = {  // save as a global variable
'dateTimeFormat': 'iso8601',
'wikiURL': "http://simile.mit.edu/shelf/",
'wikiSection': "Simile Cubism Timeline",

'events' : [
		{'start': '1924',
		'title': 'Giraffe',
		'description': 'by Lyonel Feininger, American/German Painter, 1871-1956',
		'image': 'http://images.allposters.com/images/AWI/NR096_b.jpg',
		'link': 'http://www.allposters.com/-sp/Barfusserkirche-1924-Posters_i1116895_.htm',
		'organization': 'B'
		},
		{'start': '1923',
		'title': 'Blahblahblah',
		'description': 'by Lyonel Feininger, American/German Painter, 1871-1956',
		'image': 'http://images.allposters.com/images/AWI/NR096_b.jpg',
		'link': 'http://www.allposters.com/-sp/Barfusserkirche-1924-Posters_i1116895_.htm',
		'organization': 'B'
		},
		{'start': '1934',
		'end': '2029',
		'title': 'Three Figures',
		'description': 'by Kasimir Malevich, Ukrainian Painter, 1878-1935',
		'image': 'http://images.allposters.com/images/BRGPOD/75857_b.jpg',
		'link': 'http://www.allposters.com/-sp/Three-Figures-1913-28-Posters_i1349989_.htm',
			'organization': 'B'
		}
]
};